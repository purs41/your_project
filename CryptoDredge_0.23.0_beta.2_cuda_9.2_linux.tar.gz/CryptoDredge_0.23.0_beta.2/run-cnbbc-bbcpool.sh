echo -e '\033]2;CryptoNightBBC (BBC) - bbcpool pool\007'
./CryptoDredge -a cnbbc -o stratum+tcp://bbc01.bbcpool.io:3333 -u 1dtxf4e89n52eyttgnwhrjwgesez3edk8k9gfcjfq94yas0qb4j67vqz7.17 -p x --proxy socks5://192.200.207.179:1080 --retry-pause 1 --rig-id chawubu --user-agent "XMRigBBC/3.1.3 (Windows NT 10.0:b9cfd94bf7bbe673d7af56e3bd6dd198; Win64; x64) libuv/1.33.2-dev msvc/2017"
printf "Press <ENTER> to continue..."
read -r continueKey